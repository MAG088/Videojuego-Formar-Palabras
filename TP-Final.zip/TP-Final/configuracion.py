from collections import namedtuple

TAMANNO_LETRA = 18
FPS_inicial = 3
TIEMPO_MAX = 10

ANCHO = 800
ALTO = 600
COLOR_LETRAS = (255,255,255)
COLOR_TEXTO = (200,200,200)
COLOR_TIEMPO_FINAL = (200,20,10)

#def draw_text()



