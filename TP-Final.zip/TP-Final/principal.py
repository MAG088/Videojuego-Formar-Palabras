#! /usr/bin/env python
import os, random, sys, math
import pygame
from pygame import event
from pygame.locals import *

from configuracion import *
from funcionesVACIAS import *
from extras import *

def main_menu():
    
    os.environ["SDL_VIDEO_CENTERED"] = "1"
    pygame.init()
    pygame.display.set_caption("Main menu")
    screen = pygame.display.set_mode((ANCHO, ALTO))
    
    while True:
        
        #main_Clock = pygame.time.Clock()
        BACKG = pygame.image.load("img.jpg").convert()
         
        fuente = pygame.font.Font(pygame.font.match_font("RAVIE", True, True), 20)
        fuente_menu = pygame.font.Font(pygame.font.match_font("RAVIE", True, True), 40)
        
        texto = fuente.render("Jugar", 0,(255,0,0))
        texto2 = fuente_menu.render("Menu Principal", 0, (255,0,0))
        texto3 = fuente.render("Ranking", 0,(255,0,0))
        volumen = fuente.render("Configuracion",0,(255,0,0))
        
        
        mx, my = pygame.mouse.get_pos()
        button_1 = pygame.Rect(350, 200, 100, 20)
        button_2 = pygame.Rect(330,250,125,20)
        button_3 = pygame.Rect(312,300,185,20)
        #pygame.draw.rect(screen,(255,255,255), button_1)
        
        pygame.draw.rect(screen,(255,0,0), button_3)
        screen.blit(BACKG, [0,0])
        screen.blit(texto2, (210, 100))
        screen.blit(texto,(360,200))
        screen.blit(texto3,(345,250))
        screen.blit(volumen,(312,300))
       
        
        for e in pygame.event.get():
            
            if e.type == QUIT:
                pygame.quit()
                sys.exit()
            
            if e.type == KEYDOWN:

                if e.type == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            
            if e.type == MOUSEBUTTONDOWN: # Ejecutar juego
                if button_1.collidepoint((mx, my)):
                    main()
            
            if e.type == MOUSEBUTTONDOWN:# Ir al ranking
                if button_2.collidepoint((mx, my)):
                    ranking()

            if e.type == MOUSEBUTTONDOWN: # Configurar
                if button_3.collidepoint((mx,my)):
                    config()
        
        
        pygame.display.update()
        #main_Clock.tick(60)


#Funcion principal
def main():
        
        #Centrar la ventana y despues inicializar pygame
        
        os.environ["SDL_VIDEO_CENTERED"] = "1"
        pygame.init()
        
        #pygame.mixer.init()

        #Preparar la ventana
        
        pygame.display.set_caption("Armar palabras...") # Titulo
        
        #Cargar imagen y ancho-alto
        
        screen = pygame.display.set_mode((ANCHO, ALTO))
        BACKG = pygame.image.load("img.jpg").convert()
        
        #tiempo total del juego
        gameClock = 0
        gameClock = pygame.time.Clock() # Crear un objeto que rastrea el tiempo
        totaltime = 0 # El tiempo total comienza en 0
        segundos = TIEMPO_MAX # Establecer el tiempo maximo
        fps = FPS_inicial # El juego comienza con tantos fps

        puntos = 0
        candidata = ""
        listaIzq = []
        listaMedio = []
        listaDer = []
        posicionesIzq = []
        posicionesMedio = []
        posicionesDer = []
        lista = []

        archivo = open("lemario.txt","r")
        
        for linea in archivo.readlines():
            lista.append(linea[0:-1])

        cargarListas(lista, listaIzq, listaMedio, listaDer, posicionesIzq , posicionesMedio, posicionesDer)
        dibujar(screen, candidata, listaIzq, listaMedio, listaDer, posicionesIzq ,
                posicionesMedio, posicionesDer, puntos,segundos)

        while segundos > fps/1000: # Segundos es el tiempo total y fps/1000 el tiempo que transcurre en segundos
        
        # 1 frame cada 1/fps segundos
            
            gameClock.tick(fps) # evitar disparo de fps y calcular cuantos milisegundos han pasado
            totaltime += gameClock.get_time() # Cada dos vueltas me devuelve los milisegundos(ultimas dos llamadas) y los agrega al totaltime

            if True:
            	fps = 30

            # Buscar la tecla apretada del modulo de eventos de pygame
            for e in pygame.event.get(): 

                #QUIT es apretar la X en la ventana
                if e.type == QUIT: # e.type evento de tipo...
                    pygame.quit()
                    return()

                #Ver si fue apretada alguna tecla
                if e.type == KEYDOWN:
                    
                    letra = dameLetraApretada(e.key) #Busca la tecla apretada
                    candidata += letra
                    
                    if e.key == K_BACKSPACE: 
                        candidata = candidata[0:len(candidata) - 1]
                    
                    if e.key == K_RETURN:
                        puntos  += procesar(lista, candidata, listaIzq, listaMedio, listaDer)
                        candidata = "" # Limpiar candidata

            segundos = TIEMPO_MAX - pygame.time.get_ticks()/1000 # Tiempo_total - tiempo transcurrido

            #Fondo
            screen.blit(BACKG, [0,0])
            
            #Dibujar de nuevo todo
            
            dibujar(screen, candidata, listaIzq, listaMedio, listaDer, posicionesIzq ,
                posicionesMedio, posicionesDer, puntos,segundos)

            pygame.display.flip() # Actualiza la pantalla

            actualizar(lista, listaIzq, listaMedio, listaDer, posicionesIzq,
                posicionesMedio, posicionesDer)
                                                                  
        
        archivo = open("Puntajes.txt","rb")
        puntajes = pickle.load(archivo)
        j = 0
        punto_sub = ""
        condicion = False
        for puntaje in puntajes:

                for i in range(7, len(puntaje)):
                    punto_sub = punto_sub + puntaje[i] # Obtener puntaje
                
                if puntos > int(punto_sub) and not condicion:
                    nombre = input("Por favor ingrese su nombre de 4 digitos: ")
                    nombre = nombre + " : " + str(puntos)
                    puntajes[j] = nombre
                    condicion = True

                    
                j += 1
                print(punto_sub)
                punto_sub = ""
                pygame.display.flip()
        archivo.close()

        archivo = open("Puntajes.txt","wb")
        pickle.dump(puntajes, archivo)
        archivo.close()
        print(punto_sub)
        print(puntajes)

        if condicion:
            return ranking()
            

      
        
        while 1:    
            
            #Esperar el QUIT del usuario
            
            for e in pygame.event.get():
                if e.type == QUIT:                   
                    pygame.quit()
                    return

            


               
def ranking():

    os.environ["SDL_VIDEO_CENTERED"] = "1"
    pygame.init()
    pygame.display.set_caption("Main menu")
    screen = pygame.display.set_mode((ANCHO, ALTO))
   
    #archivo = open("Puntajes.txt","wb")
    #puntajes = ["Gabi : 50", "Meli : 21", "Axel : 10"]
    
    #pickle.dump(puntajes, archivo)
    #archivo.close()
    
    archivo = open("Puntajes.txt", "rb")
    Puntajx = pickle.load(archivo)
    archivo.close()
    
            
    while True:
        
        ranking_clock =  pygame.time.Clock()
        BACKG = pygame.image.load("img.jpg").convert()

        
        
        fuente = pygame.font.Font(pygame.font.match_font("RAVIE", True, True), 20)
        title = fuente.render("Ranking de mejores jugadores", 0 , (255,0,0))
        Puesto1 = fuente.render(Puntajx[0], 1,(255,0,0))
        Puesto2 = fuente.render(Puntajx[1], 1,(255,0,0))
        Puesto3 = fuente.render(Puntajx[2], 1,(255,0,0))
        atras = fuente.render("Atras",1,(255,0,0))
        
        mx, my = pygame.mouse.get_pos()
        button_1 = pygame.Rect(50,30,100,20)

        screen.blit(title,(230,100))
        screen.blit(Puesto1,(345,200))
        screen.blit(Puesto2,(345,300))
        screen.blit(Puesto3,(345,400))
        screen.blit(atras,(50,30))
        
        #pygame.draw.rect(screen,(255,255,255),button_1)
        
        for e in pygame.event.get():
            if e.type == QUIT:
                pygame.quit()
                sys.exit()
            if e.type == KEYDOWN:

                if e.type == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            
            if e.type == MOUSEBUTTONDOWN:

                if button_1.collidepoint((mx,my)):
                    main_menu()

        
        pygame.display.update()
                                                                                                                                                                    
    
while __name__ == "__main__":
        
    main_menu()
        



##Programa Principal ejecuta Main


