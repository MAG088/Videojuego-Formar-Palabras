    from principal import *
    from configuracion import *
    from extras import *

    import random
    import math
    import pickle

    def cargarListas(lista, listaIzq, listaMedio, listaDer, posicionesIzq , posicionesMedio, posicionesDer):
        #elige una palabra de la lista y la carga en las 3 listas
        # y les inventa una posicion para que aparezca en la columna correspondiente
        
        indice = random.randint(0, len(lista) - 1) # genera valor aleatorio para la lista
        i = 0
        
        for letra in lista[indice]:#toma palabra random de la lista
            
            numero1 = random.randint(1, 3)
            
            if 1 == numero1 and letra not in listaIzq:
                
                valorX1 = random.randint(20,230) 
                listaIzq.append(letra)
                posicionesIzq.append([valorX1,0]) # posicion (x,y)

            
            if numero1 == 2 and letra not in listaMedio:
                
                valorX2=random.randint(270, 480)
                listaMedio.append(letra)
                posicionesMedio.append([valorX2, 0])#posicion (x,y)
            
            if numero1 == 3 and letra not in listaDer:
                
                valorX3=random.randint(520,730)
                listaDer.append(letra)
                posicionesDer.append([valorX3, 0])#posicion (x,y)
            i += 1
            

        pass
        


    def bajar(lista, posiciones):
        # hace bajar las letras y elimina las que tocan el piso
        
        i = 0
        while i < (len(posiciones)):
            posiciones[i][1] = posiciones[i][1] + 5 # Aumenta el valor Y
            
            if posiciones[i][1] == 515: # Toca la linea 
                
                # Se elimina del programa
                lista.pop(i)
                posiciones.pop(i)
            
            i = i + 1


        pass
    def actualizar(lista, listaIzq, listaMedio, listaDer, posicionesIzq , posicionesMedio, posicionesDer):
        ## llama a otras funciones para bajar las letras, eliminar las que tocan el piso y
        ## cargar nuevas letras a la pantalla (esto puede no hacerse todo el tiempo para que no se llene de letras la pantalla)


        bajar(listaIzq, posicionesIzq)
        bajar(listaMedio, posicionesMedio)
        bajar(listaDer, posicionesDer)
        
        
        
        azar = random.randint(0, 75)
        if azar <= 5:
            i = 0
            while i:

                if posicionesIzq[i][1] == 0:
                    estaCerca(i,posicionesIzq)
                    i = False
                i += 1
            cargarListas(lista, listaIzq, listaMedio, listaDer, posicionesIzq , posicionesMedio, posicionesDer)
            
                    

        pass

    def estaCerca(indice, lista):
        
        print(lista)
    
                
        pass

            
    
        

    def Puntos(candidata):
        #devuelve el puntaje que le corresponde a candidata
        pass

    def procesar(lista, candidata, listaIzq, listaMedio, listaDerecha):
        #chequea que candidata sea correcta en cuyo caso devuelve el puntaje y 0 si no es correcta

        
        #archivo= open("lemario.txt","rb")
        validar = False
        
        #if candidata in archivo:
        deteccion = False
        deteccion2 = False
            
        for letra in candidata:

            if letra in listaIzq and  not deteccion and not deteccion2: # la letra en lista izquierda sin las demas
                validar = True
            elif letra in listaIzq and deteccion: # Volvio a la izq pero ya paso por otra lista
                validar = False
                return 0

                
            # No esta en la izq pero si la del medio
            elif (letra not in listaIzq) and (letra in listaMedio) and not deteccion2 :
                validar = True
                deteccion = True 
            elif letra in listaMedio and deteccion2:
                validar = False
                return 0
                
            # Esta en la lista derecha y no en las demas
            elif (letra not in listaIzq) and (letra not in listaMedio) and (letra in listaDerecha):
                    
                validar = True
                deteccion2 == True
            
        if validar:
            return esValida(lista, candidata, listaIzq,listaMedio,listaDerecha)

                                                        
        return 0


    def esValida(lista, candidata, listaIzq, listaMedio, listaDerecha):
        
        #devuelve True si candidata cumple con los requisitos
        #archivos = open("lemario.txt","rb")
        #palabras = pickle.load(archivos)
        
        
        if candidata in lista:
            return 1
        else:
            return 0

        

    def config():

        os.environ["SDL_VIDEO_CENTERED"] = "1"
        pygame.init()
        pygame.display.set_caption("Configuracion")
        screen = pygame.display.set_mode((ANCHO, ALTO))

        fuente = pygame.font.Font(pygame.font.match_font("RAVIE", True, True), 20)
        volumen = fuente.render("Volumen General",0,(255,0,0))
        
        while True:
            
            screen.fill((0,0,0))
            screen.blit(volumen, (100,100))  
                    
            for e in pygame.event.get():
        
                if e.type == QUIT:
                    pygame.quit()
                    sys.exit()

                
        
            pygame.display.update()


